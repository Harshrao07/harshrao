const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();
const port = 5000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Connect to MongoDB
mongoose.connect('mongodb+srv://hannyyadav23cse:AKjX5iQFGshfVLin@cluster0.fc3ll.mongodb.net/HotelBooking?retryWrites=true&w=majority', {
    useNewUrlParser: true,
    useUnifiedTopology: true
})
.then(() => console.log('MongoDB connected successfully'))
.catch((err) => console.log('MongoDB connection error: ', err));

// Define the booking schema
const bookingSchema = new mongoose.Schema({
    name: String,
    email: String,
    phone: String,
    guests: Number,
    roomType: String
});

const Booking = mongoose.model('Booking', bookingSchema);

// POST route to handle booking data
app.post('/api/bookings', async (req, res) => {
    const { name, email, phone, guests, roomType } = req.body;

    const newBooking = new Booking({
        name,
        email,
        phone,
        guests,
        roomType
    });

    try {
        await newBooking.save();
        res.status(200).send('Booking saved successfully!');
    } catch (error) {
        console.error('Error saving booking:', error);
        res.status(500).send('Failed to save booking');
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server is running on port ${port}`);
});
