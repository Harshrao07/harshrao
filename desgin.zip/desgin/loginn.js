document.addEventListener("DOMContentLoaded", () => {
    const tabs = document.querySelectorAll(".tabs button");

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            tabs.forEach(btn => btn.classList.remove("active"));
            tab.classList.add("active");

            if (tab.innerText === "Signup") {
                window.location.href = "sign-up-page.html"; // Redirect to signup page
            }
        });
    });

    // Form validation and sample login check (for demo purposes)
    const loginForm = document.querySelector("form");
    loginForm.addEventListener("submit", (event) => {
        event.preventDefault();

        const emailInput = document.querySelector('input[type="email"]').value;
        const passwordInput = document.querySelector('input[type="password"]').value;

        // Placeholder data check (would be replaced with actual validation)
        if (emailInput === "exampleuser@example.com" && passwordInput === "password123") {
            alert("Login successful!");
        } else {
            alert("Invalid email or password.");
        }
    });
});