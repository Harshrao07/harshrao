// script.js

// Select the menu button and the menu
const menuBtn = document.getElementById('menu-btn');
const menu = document.querySelector('.menu');

// Toggle menu visibility when the menu button is clicked
menuBtn.addEventListener('click', () => {
    menu.classList.toggle('active');
    menuBtn.classList.toggle('fa-times');
});

// Close dropdown menus when clicked outside
document.addEventListener('click', (e) => {
    if (!menu.contains(e.target) && e.target !== menuBtn) {
        menu.classList.remove('active');
        menuBtn.classList.remove('fa-times');
    }
});

// Smooth scroll to sections for internal links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();

        const target = document.querySelector(this.getAttribute('href'));
        if (target) {
            target.scrollIntoView({
                behavior: 'smooth',
                block: 'start',
            });
        }
    });
});

// Toggle saved property state
document.querySelectorAll('.save button').forEach(saveBtn => {
    saveBtn.addEventListener('click', (e) => {
        e.preventDefault();
        saveBtn.classList.toggle('fas');
        saveBtn.classList.toggle('far');
    });
});

// Prevent form submission and display a message for the search form
document.querySelector('.home form').addEventListener('submit', (e) => {
    e.preventDefault();
    alert('Search functionality is not implemented yet.');
});

// Add active state for the current menu item (example for demo purposes)
const currentPath = window.location.pathname.split('/').pop();
document.querySelectorAll('.menu a, .header ul a').forEach(link => {
    if (link.getAttribute('href') === currentPath) {
        link.classList.add('active');
    }
});

// Add responsiveness for the header menus
window.addEventListener('resize', () => {
    if (window.innerWidth > 768) {
        menu.classList.remove('active');
        menuBtn.classList.remove('fa-times');
    }
});
